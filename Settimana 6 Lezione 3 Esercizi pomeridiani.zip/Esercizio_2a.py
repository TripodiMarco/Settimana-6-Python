import pandas as pd
file_path="./bezdekIris.data"
dataframe=pd.read_csv(file_path)
print(dataframe.head())
print(dataframe.head(0))