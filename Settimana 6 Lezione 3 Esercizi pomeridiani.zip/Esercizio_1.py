import pandas as pd
file_path="./wine.csv"
data=pd.read_csv(file_path,sep=",",header=0)
print(data.describe())