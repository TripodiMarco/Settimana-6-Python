'''
In una catena di montaggio abbiamo una struttura metallica 
di 28.75 cm di lunghezza; per assicurarne la stabilità, 
è necessario inserire 15 rivetti, dei quali uno all'inizio e 
uno alla fine, e tutti quanti separati dalla stessa distanza; 
come possiamo calcolare i punti esatti in cui inserire i rivetti tramite NumPy?
'''
import numpy as np
struttura=28.75                        # impostiamo una variabile che sarà utilizzata nella funzione di numpy linspace
print(np.linspace(0,struttura,15))