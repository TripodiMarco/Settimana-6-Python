# Abbiamo il seguente array NumPy:
import numpy as np
linear_data = np.array([x for x in range(27)])

# Lo ridimensioniamo mediante il metodo .reshape():
reshaped_data = linear_data.reshape((3, 3, 3))

# Quante dimensioni ha il nuovo array?
print("Il nuovo arrey ha le seguenti dimensioni:",np.shape(reshaped_data))

# Per accedere ai singoli elementi:
print(reshaped_data[1,2,0])