import numpy as np
matrice=np.array([[10,22,21,8,9],
                  [9,42,3,18,11],
                  [5,4,30,12,29],
                  [37,31,7,2,26],
                  [8,6,4,33,15]])
# Per ogni valore, sottraiamo il minimo (2) e poi dividiamo il risultato per il massimo (42) meno il minimo. 
print((matrice[:]-np.min(matrice))/(np.max(matrice)-np.min(matrice)))