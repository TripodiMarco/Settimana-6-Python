# Metodo 1 per creare una matrice
import numpy as np
matrice=np.array([[1,1,1,1],
         [5,1,1,1],
         [20,-4,0,42]])
print(matrice)

# Metodo 2 per creare una matrice
matrice=[[1,1,1,1],
         [5,1,1,1],
         [20,-4,0,42]]
print(np.array(matrice))